create database if not exists company_db;

use company_db;

create table if not exists companies(
company_id INT PRIMARY KEY,
company_name VARCHAR(100) NOT NULL
);

create table if not exists departments(
dept_id INT PRIMARY KEY,
dept_name VARCHAR(100) NOT NULL,
company_id INT,
foreign key (company_id) references companies(company_id) on delete cascade
);


CREATE TABLE IF NOT EXISTS employees (
    emp_id INT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    dept_id INT,
    salary DECIMAL(10, 2) NOT NULL,
    hire_date DATE NOT NULL,
    manager_id INT,
    job_title VARCHAR(100) NOT NULL,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id) ON DELETE SET NULL,
    FOREIGN KEY (manager_id) REFERENCES employees(emp_id) ON DELETE SET NULL
);